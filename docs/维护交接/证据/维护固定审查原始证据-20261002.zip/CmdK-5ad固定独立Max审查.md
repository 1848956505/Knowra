# CmdK 正文搜索固定提交独立 Max 审查

结论：固定提交有 **1 项已动态复现的 P2 问题**：有效服务端命中尚未进入页面工作区摘要时，选择后仅改变 URL，编辑主区显示“未找到这篇笔记”，不读取该笔记。建议修复后重新冻结并复审。未发现其他可复现的 P0/P1/P2/P3 问题；现有轻量目标通过不消除这项独立失败，也不代表最终生产验收。

审查对象为只读工作树 `/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search`。开始与结束均为：

| 项目 | 实际值 |
| --- | --- |
| 完整 HEAD | `5ad5626b9db35c5b2bebea8c49a416d74d28413d` |
| tree | `7789946759d77556df94fbaf810a5945f24d3356` |
| base | `3811447f5f2243278fa7de823b3d359ff5e7e13c` |
| 工作区 | `git status --porcelain=v1` 输出为空 |
| 差异 | 29 个文件，1069 行增加、33 行删除；全部 diff 已审查 |
| 文件一致性 | 29 个差异文件的开始/结束 SHA-256 全部一致 |

开始记录为 UTC `2026-10-02T14:50:48.814761+00:00`；结束核验为 UTC `2026-10-02T15:03:56.852817+00:00`。记录见 [start JSON](CmdK-5ad-Max-start.json)、[end JSON](CmdK-5ad-Max-end.json) 和 [完整差异](CmdK-5ad-Max-diff.patch)。Node 使用父线程指定的 Node 24 runtime。已读取根 AGENTS、开发规范、相关结构导航、CmdK 实现记录，以及当前领域导航的相关部分；未以归档设计推断当前行为。

## P2：有效正文命中不在工作区摘要中时，选择结果打不开

新增入口位于 [App.tsx:357](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/app/App.tsx:357)，具体问题在 `state.selectNote(note.id)` 与随后 `navigate(...)`：它把搜索 DTO 当作已经存在于 `serverData.notes` 的笔记，既未补载资料，也未把有效命中对应的详情加入当前工作区。

触发条件是页面完成初次摘要加载后，当前空间的服务端新增了笔记，例如另一页面或设备新增，当前页面尚未刷新摘要。命令接口能实时找到该笔记，命中本身合法、属于当前 owner/space、未删除；用户对该命中按 Enter，搜索面板关闭，实际编辑页却报未找到。

这是新增服务端检索能力造成的可达场景：旧本地标题检索只从已加载笔记生成命中。新正文命中已经可以包含摘要集合以外的 ID，但仍调用仅接受已加载 ID 的旧选择路径。

支持源码为 [navigationSlice.ts:53](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/store/slices/navigationSlice.ts:53) 的存在性过滤，以及 [AppRoutes.tsx:210](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/app/AppRoutes.tsx:210) 仅在集合中存在 note 时才调用正文加载。现有 [workspaceSlice.ts:185](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/store/slices/workspaceSlice.ts:185) 对集合缺失也直接返回。结论以以下动态结果为准，没有仅凭这些源码片段定级。

独立复现使用正式 `App`、`AppProviders`、RouterProvider、store 和当前源码 API 知识模块，所有记录为内存合成数据。先让 App 成功加载空笔记摘要，再通过知识模块新建同 owner/space 的合成笔记；搜索能力调用正式 `searchService.searchCommandNotes`。客户端的工作区加载与详情方法均可以读到新笔记，不人为限制后续加载。RouterProvider 的 navigate 确实更新 pathname 并重新渲染实际编辑主区。

实际结果（UTC `2026-10-02T15:02:06.993395+00:00`）：

```json
{
  "route": "/materials/notes/command-new-server-note",
  "selectedNoteId": null,
  "storedNoteIds": [],
  "workspaceLoadCalls": 1,
  "getNoteCalls": [],
  "editorTitlePresent": false,
  "mainText": "未找到这篇笔记它可能尚未加载、已被删除，或链接已经失效。",
  "detailPromptPresent": true,
  "missingHeadingPresent": true
}
```

测试先确认 CmdK option 含正确标题与正文关键词，且请求绑定实际当前空间，再按 Enter。最后“应出现该笔记的编辑标题并读取详情”的用户结果断言失败，**0/1，业务 red**。页面 URL 正确本身不足以证明打开成功。

可复跑入口和证据均在源码树之外：

- [独立合成 test](CmdK-5ad-Max-remote-opening.test.tsx)
- [独立 Vitest 配置](CmdK-5ad-Max-probe.vitest.config.mjs)，将 web-core 映射到当前源码，避免依赖旧 dist；不运行 build。
- [有效失败原始日志](CmdK-5ad-Max-remote-opening.log)
- [命令、时间、退出码和观测 JSON](CmdK-5ad-Max-remote-opening.json)

从 `审查证据/` 运行：

```sh
PATH=/Users/rabbids/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH node ../knowra-command-search/node_modules/vitest/vitest.mjs run --config CmdK-5ad-Max-probe.vitest.config.mjs --configLoader=runner --no-cache --maxWorkers=1
```

独立夹具最初两次因为外部 root 的 setup 路径未正确配置而没有执行任何测试，另一次因 JSDOM 不实现 `Element.scrollTo` 失败。这些原始日志分别保存在 `CmdK-5ad-Max-remote-opening-config-error*` 和 `CmdK-5ad-Max-remote-opening-environment-error*`，不计作业务 red。最终夹具仅补该浏览器 API 的无业务 stub；有效失败来自真实编辑主区的缺失状态。

建议在处理服务端命中时确保它对应的笔记已经取得并进入当前空间资料集合，再选择、跳转和宣告打开；获取前后复核当前空间，拒绝已删除、ID/空间不一致或过期响应。补充“摘要加载后新增服务端笔记”的结果断言，同时保护获取过程中换空间的场景。未知 ID 的目录元数据也应沿用已有合法路径处理。

## 实际检查与覆盖

| 检查 | 实际结果 | 原始证据 |
| --- | --- | --- |
| 显式 API runner `node apps/api/test/run-command-search-tests.js` | 33/33；真实 PostgreSQL 明确 SKIP | [log](CmdK-5ad-Max-api-target-approved.log)、[JSON](CmdK-5ad-Max-api-target-approved.json) |
| core：command-note-search / api-client 两个目标 | 30/30 | [log](CmdK-5ad-Max-core-target.log)、[JSON](CmdK-5ad-Max-core-target.json) |
| V4：SearchCommand / commandNoteSearch / App / createAppStore 四个目标 | 66/66 | [log](CmdK-5ad-Max-ui-target.log)、[JSON](CmdK-5ad-Max-ui-target.json) |
| core/V4 `tsc --noEmit` | 均通过 | [static log](CmdK-5ad-Max-static.log)、[JSON](CmdK-5ad-Max-static.json) |
| V4 architecture boundary、base→head diff check | 均通过 | 同上 |
| 12 个差异 JS/MJS 的 `node --check`，包含新生产 E2E | 全部通过；没有执行 E2E | 同上 |
| 独立未知 ID 打开结果检查 | 0/1，确证上述 P2 | [log](CmdK-5ad-Max-remote-opening.log)、[JSON](CmdK-5ad-Max-remote-opening.json) |

API 第一次执行为 29/33，其 4 个 HTTP 用例全部因为 sandbox `listen EPERM 127.0.0.1` 失败。随后自动审批允许同一个定向 runner 仅监听随机回环端口、使用临时合成根，得到 33/33；先前 [EPERM log](CmdK-5ad-Max-api-target.log) 与 [JSON](CmdK-5ad-Max-api-target.json) 保留，不作为业务失败或额度失败。本机两个 PostgreSQL 配置门控均未启用，未尝试启动或连接数据库。

已核查的行为与实现边界：

- **服务端 owner 装配**：JSON/API factory 将 resolve 后的 owner 注入 handler；SQLite runtime 显式 `demo`；异步 PG factory 注入 normalized owner。命令分支不读取客户端 owner/userId，使用空间 repository 的真实 `userId` 判定。跨 owner 请求动态返回 404，且没有 data。
- **输入与窄 DTO**：space 必需，query/space 最多 200 UTF-16 单元；limit 必须为正安全整数，最多 30。强制非 deleted、逐条复核 space。四字段投影没有 rawMarkdown/full plainText。中文深处命中、标题命中、200 字查询、İ 小写扩长前缀、emoji 边界、limit 与无效输入已由实际 HTTP 目标覆盖；片段含省略号最多 220 UTF-16 单元。
- **异步与选择隔离**：hook render 通过完整 scope 身份阻断旧结果，effect cleanup 阻断旧成功/失败发布；A→B→A、倒序、换空间、关闭、清空、180ms 防抖、IME 和 229 均有实际目标覆盖。store 查询前后复核当前空间。App 的新 remote closure 选择时也复核空间，但这不能补足未知 ID 的加载。
- **已有交互兼容**：本地标题与正文同 ID 去重；远端正文不再按标题二次过滤；标签、主页、方向键、清空、已加载笔记目录选择和导航目标检查通过。原 `result=ids`、完整 note 搜索与 NotesIndex 的 includeDeleted=true 契约保持通过。
- **真实 PG 注册**：新 PostgreSQL test 在 standalone runner 和 `apps/api/test/run-tests.js` 中均实际注册，按获准测试 URL/write gate 启用；使用正式 `createPostgresAppContext` 与独立 schema，随后注入异 owner 检查 handler。CI 配置提供这两个环境门控并运行 API runner。这里只核查入口；本机 async HTTP 用例是内存协议验证，不能替代真实 PG 执行。
- **生产夹具与断言**：新 E2E 的 Range 检查对命中全部 UTF-16 范围的每个矩形核对 snippet 边界，检查内容比仅 DOM contains 严格；desktop 与 390px 都调用该检查。真实 SQL/HTTP 夹具的 summary 等待、deleted/其他空间排除、进入正文和浏览器错误断言已静态核查。该夹具在 CmdK 前明确等待命中笔记按钮，所以只能证明摘要中已有 ID 的路径，不能覆盖此次 P2。
- **文档证据**：轻量计数本次独立重现。历史 production/result.json 的 build commit 确实为 `d35b9d8d91665b172886c34ff08ba41a2c3a74f6`、clean、UTC build `2026-10-02T14:25:52.796Z`，完成 UTC `2026-10-02T14:26:45.331Z`，没有新 `visibleViewports` 回执。现有 production/result.json 与 history 副本 SHA-256 相同，均为 `cc87e46ba81bf039617d73e3adf002691870654ef385409ee0d3a773059eb857`。文档明确区别旧通过和新 CSS/Range 未执行，未把旧包记作 fixed head 生产验收；“正确打开”的能力范围仍受上述 P2 限制。

## 仍待执行的门禁与权限边界

- 修复本次 P2，新增未知 ID / 获取中空间切换的结果检查，在修复提交上复审。
- 获准的本地重型窗口释放后，实际执行新可见性断言的旧 CSS red 与新 CSS green；为最新源码记录准确 buildInfo、desktop/390px 回执。此审查没有运行构建、Chromium、GUI、Electron 或任何 App。
- 真实 PostgreSQL 新用例以及固定后续提交的完整 CI；本次没有执行完整测试，也没有修改 CI 编排。
- PR25→26→27 队列完成并 sync main 后，以最终完整 HEAD/tree 重新核验。此报告只覆盖上面固定的 5ad，不向未来提交转移通过结论。

审查期间没有修改、commit、rebase、push、merge、部署、安装或关闭 App；没有访问真实笔记、凭据、系统剪贴板、reset cards，也没有读取或运行被独占的 R07 fixture/E2E。没有额度不足或降档。本次剩余阻塞是确证的 P2 以及父线程安排的上述生产/PG/最终 CI 门禁。

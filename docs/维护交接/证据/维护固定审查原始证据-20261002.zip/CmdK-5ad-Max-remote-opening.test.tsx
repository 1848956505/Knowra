import { useState } from 'react';
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { createEmptyWorkspaceSnapshot, type WorkspaceApi } from '@study-accelerator/web-core';
import { App } from '../knowra-command-search/apps/web-v4/src/app/App';
import { AppProviders } from '../knowra-command-search/apps/web-v4/src/app/AppProviders';
import { RouterProvider } from '../knowra-command-search/apps/web-v4/src/app/router';
import { createAppStore } from '../knowra-command-search/apps/web-v4/src/store/createAppStore';
import { createKnowledgeModule } from '../knowra-command-search/apps/api/src/modules/knowledge/index.js';

it('独立复现：服务端有效正文命中在摘要加载后新增，选择后应打开并获取该笔记', async () => {
  // JSDOM 不实现 Element.scrollTo；只补这个无业务逻辑的浏览器 API。
  Object.defineProperty(HTMLElement.prototype, 'scrollTo', { configurable: true, value: vi.fn() });
  const knowledge = createKnowledgeModule({ enforceReferences: true });
  const space = knowledge.knowledgeSpaceService.createDefaultKnowledgeSpace({ userId: 'demo' });
  const api = createWorkspaceApiStub({ notes: [] });
  vi.mocked(api.listKnowledgeSpaces).mockResolvedValue([space]);
  api.loadWorkspaceResources = vi.fn(async () => ({ folderTree: [], tags: [], tagGroups: [],
    notes: knowledge.noteService.listNotes({ spaceId: space.id, summaryOnly: true }) }));
  api.getNote = vi.fn(async id => knowledge.noteService.getNote(id));
  api.searchCommandNotes = vi.fn(async input => knowledge.searchService.searchCommandNotes(input, 'demo'));
  const store = createAppStore({ api, cacheKey: 'synthetic-independent-probe', mockSnapshot: createEmptyWorkspaceSnapshot() });
  const routes: string[] = [];
  function Harness() {
    const [pathname, setPathname] = useState('/');
    const navigate = (next: string) => { routes.push(next); setPathname(next); };
    return <RouterProvider location={{ pathname, navigate }}><AppProviders store={store}><App /></AppProviders></RouterProvider>;
  }
  render(<Harness />);
  await waitFor(() => expect(store.getState().dataMode).toBe('api'));
  expect(store.getState().serverData.notes).toHaveLength(0);
  // 页面摘要加载完之后新增；mock 的加载/详情方法也能真实读到这篇合成资料。
  const note = knowledge.noteService.createNote({ id: 'command-new-server-note', spaceId: space.id,
    title: '独立合成新增服务端笔记', rawMarkdown: '前文内容。'.repeat(100) + '独立正文命中' });
  fireEvent.keyDown(window, { key: 'k', ctrlKey: true });
  const dialog = await screen.findByRole('dialog', { name: '全局搜索' });
  fireEvent.change(within(dialog).getByRole('combobox'), { target: { value: '独立正文命中' } });
  const option = await within(dialog).findByRole('option', { name: /独立合成新增服务端笔记/ });
  expect(option).toHaveTextContent('独立正文命中');
  expect(api.searchCommandNotes).toHaveBeenCalledWith({ query: '独立正文命中', spaceId: space.id });
  fireEvent.keyDown(within(dialog).getByRole('combobox'), { key: 'Enter' });
  await waitFor(() => expect(screen.queryByRole('dialog', { name: '全局搜索' })).not.toBeInTheDocument());
  const detailPrompt = screen.queryByText('它可能尚未加载、已被删除，或链接已经失效。');
  console.info('CMDK_REMOTE_OBSERVATION ' + JSON.stringify({
    route: routes.at(-1), selectedNoteId: store.getState().navigation.selectedNoteId,
    storedNoteIds: store.getState().serverData.notes.map(item => item.id),
    workspaceLoadCalls: vi.mocked(api.loadWorkspaceResources).mock.calls.length,
    getNoteCalls: vi.mocked(api.getNote).mock.calls,
    editorTitlePresent: !!screen.queryByRole('heading', { name: note.title, exact: true }),
    mainText: document.querySelector('main')?.textContent, detailPromptPresent: !!detailPrompt,
    missingHeadingPresent: !!screen.queryByRole('heading', { name: '未找到这篇笔记', exact: true })
  }));
  expect(routes.at(-1)).toBe('/materials/notes/command-new-server-note');
  // 用户结果断言：应读取有效命中并打开正文，不能只改变 URL。
  await screen.findByRole('heading', { name: note.title, exact: true });
  expect(api.getNote).toHaveBeenCalledWith(note.id);
});

function createWorkspaceApiStub(overrides: { notes?: Array<Record<string, unknown>> } = {}): WorkspaceApi {
  const defaultNote = {
    id: 'note-1',
    spaceId: 'space-1',
    title: 'Note',
    folderId: 'folder-1',
    tagIds: [],
    internalLinks: [],
    rawMarkdown: '',
    contentLoaded: false,
    favorite: false,
    deleted: false
  };
  const notes = overrides.notes !== undefined ? overrides.notes : [defaultNote];
  return {
    listKnowledgeItems: vi.fn().mockResolvedValue([]),
    listTrainingAssets: vi.fn().mockResolvedValue([]),
    listKnowledgeSpaces: vi.fn().mockResolvedValue([{ id: 'space-1', name: 'Main' }]),
    createDefaultKnowledgeSpace: vi.fn().mockResolvedValue({ id: 'space-1', name: 'Main' }),
    loadWorkspaceResources: vi.fn().mockResolvedValue({
      folderTree: [{ id: 'folder-1', name: 'Folder', parentId: null, children: [] }],
      notes,
      tags: []
    }),
    searchNoteIds: vi.fn().mockResolvedValue([]),
    createNote: vi.fn().mockResolvedValue({ id: 'created-note' }),
    importMarkdownNotes: vi.fn().mockResolvedValue([{ id: 'imported-note' }]),
    getNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    createFolder: vi.fn().mockResolvedValue({ id: 'created-folder' }),
    updateNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    deleteNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    restoreNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    permanentlyDeleteNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    setNoteFavorite: vi.fn().mockResolvedValue({ id: 'note-1' }),
    setNoteTags: vi.fn().mockResolvedValue({ id: 'note-1' }),
    createTag: vi.fn(), updateTag: vi.fn(), deleteTag: vi.fn(), mergeTags: vi.fn(), reorderTags: vi.fn(),
    createTagGroup: vi.fn(), updateTagGroup: vi.fn(), deleteTagGroup: vi.fn(),
    deleteNotes: vi.fn().mockResolvedValue([]),
    assignTagToNotes: vi.fn().mockResolvedValue([]),
    updateTagsForNotes: vi.fn().mockResolvedValue([]),
    queryNotes: vi.fn().mockResolvedValue({ items: notes, hasNext: false }),
    getLinkedNotes: vi.fn().mockResolvedValue([]),
    listAnnotations: vi.fn().mockResolvedValue([]),
    createAnnotation: vi.fn(),
    deleteAnnotation: vi.fn(),
    restoreAnnotation: vi.fn(),
    updateAnnotationAnchor: vi.fn(),
    listNoteVersions: vi.fn().mockResolvedValue([]),
    getNoteVersion: vi.fn().mockResolvedValue({ id: 'version-1' }),
    listNoteAttachments: vi.fn().mockResolvedValue([]),
    uploadNoteAttachment: vi.fn().mockResolvedValue({ id: 'attachment-1' }),
    renameNoteAttachment: vi.fn().mockResolvedValue({ id: 'attachment-1' }),
    inspectAttachmentDeletion: vi.fn().mockResolvedValue({ asset: { type: 'attachment', id: 'attachment-1' }, decision: 'can-purge-no-history', references: [], reasonCodes: [], coverage: { persistedCurrentAndHistory: true } }),
    verifyNoteAttachment: vi.fn(),
    restoreNoteAttachment: vi.fn(),
    listAttachmentCleanup: vi.fn().mockResolvedValue({ items: [], pending: 0 }),
    retryAttachmentCleanup: vi.fn().mockResolvedValue({ completed: 0, pending: 0 }),
    deleteNoteAttachment: vi.fn().mockResolvedValue({ id: 'attachment-1' }),
    updateFolder: vi.fn().mockResolvedValue({ id: 'folder-1' }),
    deleteFolder: vi.fn().mockResolvedValue([]),
    emptyRecycleBin: vi.fn().mockResolvedValue({ deletedCount: 0 })
  };
}

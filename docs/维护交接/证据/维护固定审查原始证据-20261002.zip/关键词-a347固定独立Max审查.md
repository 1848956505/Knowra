独立 Max 固定 HEAD 审查：授权关键词检索覆盖

结论：本次完整差异审查未发现新增、可复现的 P0/P1/P2/P3 缺陷。第 301 篇召回修复、预算和候选排序、R02 当前来源/外发复核以及 R04/R06 兼容回归均获得有效证据。结论只覆盖下面的冻结候选，不覆盖后续 main 同步或新的提交。

| 身份 | 开始 | 结束 |
| --- | --- | --- |
| HEAD | `a347ea5bce6f48069247021848d70afcc19a74ea` | `a347ea5bce6f48069247021848d70afcc19a74ea` |
| Tree | `69a13f893984a8e6c7df18b3c9d85fd067aec4b9` | `69a13f893984a8e6c7df18b3c9d85fd067aec4b9` |
| Clean | true；porcelain 为空 | true；porcelain 为空 |
| 时间（UTC） | 首次核对 `2026-10-02T15:40:21+00:00`；身份文件 `2026-10-02T15:43:04.895618+00:00` | `2026-10-02T16:04:34.619311+00:00` |

仓库：`1848956505/Knowra`；工作树：`/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-keyword-coverage`；分支：`fix/authorized-keyword-coverage`；差异基线：`3811447f5f2243278fa7de823b3d359ff5e7e13c`。8 个改动文件开始/结束的 Git blob 和 SHA-256 均一致，完整 diff 已保存。审查没有修改源码、提交、push、rebase 或创建子代理。

已读根 AGENTS.md、开发规范、项目结构导航的 API/AI/测试相关章节，以及 R02/R04/R06 验收记录；结合当前代码核对授权、来源和外发契约。完整 8 文件范围如下。

| 文件 | 审查重点 |
| --- | --- |
| `apps/api/src/modules/ai/access-service.js` | 当前 owner/空间/固定集合/目录/排除/删除过滤；grant/revision/epoch；输入预算；二分有序候选池；当前版本身份/正文哈希；受信 read 可选上限与默认兼容。 |
| `apps/api/src/modules/ai/keyword-search.js` | 逐码点 NFKC/小写预选与原评分一致；标题5分、正文2分、同分ID；候选再次读取和命中末次读取；原文 UTF-16 边界与 quoteHash；空分词仍复核 grant。 |
| `apps/api/src/modules/ai/agent-worker.js` | 仅改通用处理上限说明；现有工具结果字段、外发清单、notes_read 和写入/提炼边界未扩展。 |
| `apps/api/test/ai-agent-r04.test.js` | 新预算受限说明和工具结果投影断言实际执行。 |
| `apps/api/test/ai-keyword-coverage.test.js` | 全部27条：JSON/SQLite、预算边界、排序、授权/来源变化、空正文、Unicode、坏版本和 read 兼容。 |
| `apps/api/test/ai-keyword-coverage-postgres.test.js` | 正式 Prisma/repository 和领域保存；独立 schema 及失败清理；真实 owner/空间、引用更新、处理上限和撤销。 |
| `apps/api/test/run-tests.js` | 两个新集合同时有 import 和执行数组 spread；测试采用显式 `.run()`，没有把导入当执行。 |
| `docs/AI功能/p2/授权关键词检索覆盖验收.md` | 新预算、计数含义、全量 repository.list 和非串行快照边界、合成/真实PG/HTTP真实性说明与代码相符。 |

| 严重级别 | 新增可复现发现 |
| --- | --- |
| P0 | 未发现 |
| P1 | 未发现 |
| P2 | 未发现；原“任意前300篇”覆盖缺陷在本候选得到修复证据。 |
| P3 | 未发现；下面的限制作为已声明边界记录，不冒称全库/原子快照保证。 |

独立本机验证使用 Node `v24.19.0`、已有依赖和临时合成资料。原始日志和逐项结果已保存，实际逐条等待 `testCase.run()`。

| 验证 | 实际结果及证据 |
| --- | --- |
| 正式轻量回归 | 覆盖27 + R06 7 + 非HTTP R02 5 + 非HTTP R04 10，共49/49；[原始日志](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-regression.log)、[逐项JSON](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-regression.json)。R06词面top3为27/27，无命中2/2，语义改写观察仍为1/3。 |
| 独立合成探针 | 14/14；包括默认5000/5001篇、默认400万字符恰好/超限、标题计费、池满后同分小ID替换、10查询/12笔记基线oracle、异步目录撤销、空候选后的4种授权失效、read-only grant、未授权字段访问即抛错、emoji单篇200000/200001与普通read。[原始日志](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-probes.log)、[逐项JSON](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-probes.json)。 |
| 独立原缺陷红→绿 | JSON/SQLite各正文/标题4例：原关键词模块实际 `hits=[]`、要求第301篇的断言为 ERR_ASSERTION，本HEAD召回第301篇。采用 git show 的基线关键词模块，仅重定向其哈希模块import，配本HEAD的合法R02 fixture；不是完整基线checkout实库运行。[实际红日志](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-baseline-red.log)。这4例已包含在14探针中，未重复计数。 |
| 静态检查/注册门控 | 7个JavaScript改动文件node --check和完整base..HEAD的git diff --check通过。PG无URL/只URL/只写许可均注册0；两个门控均满足注册1、函数存在；未在本机调用PG `.run()`。[日志](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-static.log)、[JSON](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-static.json)。 |

授权与来源的范围明确：不在当前授权范围的笔记不会进入正文评分或消耗授权扫描计数；超长正文计入篇数、跳过并标记 oversize。4,000,000 是首次预选的标题+Markdown UTF-16 输入预算；不是后续全部哈希或 repository.list 的全量读取上限。300限制匹配后版本验证/评分的候选池，池满仍在扫描预算内保留全体排序前300。返回 top-k 自身不制造截断；实际 notes/chars/candidates/oversize 限制会标记 truncated。

版本、标题、删除、目录移动以及被复核观察到的 grant/owner/revision/epoch 变化均有拒绝旧结果的断言。普通 R02 read 省略/null 上限仍可读取大正文；关键词的受信上限在当前正文哈希/版本查询之前生效。引用仍从权威当前版本生成原文片段和 quoteHash，外发仍需 R02 清单复核，模型没有扫描预算或评分函数入口。

PROBE10实际记录了声明过的非串行快照空隙：在末次版本读取取得旧记录后保存新正文，搜索可以返回旧hit；随后 R02 `withAuthorizedRequest` 对既有清单实际报 `AI_SOURCE_STALE`，发送回调为0次。这条探针通过表示“空隙可复现且此时外发门禁阻断”，不表示所有并发交错均具原子性，也不把该已声明边界判成新增P2。每次模型发送的当前来源/授权复核仍是必要前提。

已另外只读核对父线程保存的 [CI 37028453441](https://github.com/1848956505/Knowra/actions/runs/37028453441) 原始结果与日志：run.headSha为 `a347ea5bce6f48069247021848d70afcc19a74ea`，两个job均success；新真实PG关键词回归在原始日志1043行、`2026-10-02T15:40:42.6545141Z`明确PASS，API465/465、V4 520/520、runtime182/182、Chromium34/34的汇总行均已核对。[CI核对JSON](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-ci-verification.json) 与 [保留行号的摘录](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-ci-excerpts.log) 保存来源/哈希。

该CI实际Checkout是PR合并结果 `76a5a500caa6ef7334c9b86d7a292b42653217b2`（a347并入 `4bb55088e411cfaa9a09331396a94903cd1843e2`），因此它是对应候选的合并结果实库/集成证据，不是本机或裸分支HEAD的PG实测。原始 `ci-result.json` / `ci-full.log` 留在 `dist/keyword-evidence/pr31-a347/`，未复制改名覆盖。KW15异步memory协议仍不能替代实库，PG实际PASS来源是这条CI日志。

没有本次审查阻断项。本机两条HTTP未执行，不计绿；本机没有运行build、浏览器、fullsuite、本地PG、GUI、安装或付费模型，也未读取真实笔记、用户凭据、系统剪贴板或用户App。后续不同HEAD仍需重新绑定审查和CI；当前报告不替代正式发布、性能隔离或真实供应商语义质量验收。

证据索引：[合并metadata](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-metadata.json)、[开始](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-start.json)、[结束](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-end.json)、[完整8文件diff](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/关键词-a347-Max-full-diff.patch)。独立执行脚本位于忽略目录 `dist/keyword-review-max/run-review.mjs` 和 `probes.mjs`，哈希记录在metadata。实现者既有red/size-race-red/green日志哈希已核对，但不并入本次独立执行计数。

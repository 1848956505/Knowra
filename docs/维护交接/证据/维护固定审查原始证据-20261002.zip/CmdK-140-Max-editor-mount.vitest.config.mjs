import { mergeConfig } from '../knowra-command-search/node_modules/vitest/dist/config.js';
import base from '../knowra-command-search/apps/web-v4/vitest.config.ts';
export default { ...base,
  root: "/Users/rabbids/Documents/Codex/2026-10-01/task-3/\u5ba1\u67e5\u8bc1\u636e",
  cacheDir: "/Users/rabbids/Documents/Codex/2026-10-01/task-3/\u5ba1\u67e5\u8bc1\u636e" + '/CmdK-140-Max-editor-mount-cache',
  server: { fs: { allow: ['/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search', '/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据'] } },
  resolve: { alias: {
    '@study-accelerator/web-core': "/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search" + '/packages/web-core/src/index.ts',
    '@testing-library/react': "/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search" + '/node_modules/@testing-library/react/dist/index.js',
    'react/jsx-runtime': "/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search" + '/node_modules/react/jsx-runtime.js',
    'react/jsx-dev-runtime': "/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search" + '/node_modules/react/jsx-dev-runtime.js',
    'react': "/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search" + '/node_modules/react/index.js'
  } },
  test: { ...base.test, setupFiles: ["/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search" + '/apps/web-v4/src/test/setup.ts'],
    include: ['CmdK-140-Max-editor-mount.test.tsx'], cache: false, maxWorkers: 1 }
};

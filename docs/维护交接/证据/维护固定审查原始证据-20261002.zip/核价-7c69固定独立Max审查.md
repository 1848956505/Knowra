# 核价刷新固定 head 独立 Max 审查

结论：未发现本次差异引入的可复现 P0／P1／P2／P3 问题，`findings=[]`。独立执行获准的轻量核价 runner，实际 **10/10 通过、退出码 0**。本结论覆盖下面的固定源码身份和合成工程边界。

## 固定身份与范围

- 源目录：`/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh`。
- Head：`7c69f18acc90aa0ce748c0d8844f14c9c6a1e390`。
- Tree：`9e78dad80c7715c5bfbff3c7644a68d35d5b7e9e`。
- Base：`3811447f5f2243278fa7de823b3d359ff5e7e13c`。
- 开始与结束的 full head、tree 完全匹配；两次 `git status --porcelain=v1` 均为空。复查结束时间为 `2026-10-02T15:13:43.086079Z`。
- 已读取根 `AGENTS.md`、`docs/开发规范.md`、项目结构导航的 API／AI／桌面／测试入口、`docs/AI功能/README.md`、相关预算契约和历史 P1 记录；没有目录内追加的 `AGENTS.md`。
- 已完整读取 base→head 的 **9 文件 diff**：价格档案、既有 HTTP case、预算测试注册、新核价测试、新轻量 runner，以及四份文档。辅助检查了报价、Worker／Agent、JSON 预算、API／桌面装配、隔离 Worker 传递和 Gateway 格式序列化。
- 全程只读源树；仅在根目录外的审查证据目录写入报告及日志。未执行源码修改、commit／rebase／push／merge、外部评论或队列合并。

## 核对结果

| 核对项 | 结果及源码依据 |
| --- | --- |
| 公开价格来源 | 独立浏览了 [DeepSeek 官方中文模型与价格页](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/)，模型列为 `deepseek-flash`／`DeepSeek-V4.1-Flash`，高峰未命中输入 2 元、输出 8 元／百万 token；与提供快照对应列一致。保守使用该高档处理空闲／缓存命中符合本次范围。 |
| 单位、版本与本地截止 | [价格档案](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/api/src/modules/ai/reviewed-price-profile.js:5) 以微元保存 2,000,000／8,000,000，版本为 `deepseek-flash-cny-2026-10-02`，截止 `2026-10-09T00:00:00.000Z`。这是一周本地复核窗口；注释与文档均未称供应商价格保证。官方页面保留调整价格的权利。 |
| 边界、模型与请求格式 | [报价](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/api/src/modules/ai/worker.js:17) 在 `expiresAt <= now` 时拒绝，正式档案模型严格匹配。新回归固定旧真实截止、新截止前 1ms、整点、后 1ms；坏日期／负费率／NaN／缺档案和其他模型拒绝。报价沿用 Gateway 规范化与同一完整 JSON 序列化入口，文本／JSON 格式及工具定义仍计入外发体（格式链路为静态核对）。 |
| 预留期间到期 | [Worker 发送前复检](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/api/src/modules/ai/worker.js:168) 与 [Agent 发送前复检](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/api/src/modules/ai/agent-worker.js:83) 继续使用传入档案。独立回归观察到预留跨截止时 gateway 调用数为 0，结算为 `released`，held／spent 均为 0；先到期时没有预算预留。 |
| 金额与已知用量 | 固定 112 字节请求按输入 224、输出 800 微元估计，两倍预留为 2048 微元。10 输入／5 输出 token 按同一档案结算 60 微元。供应商用量超界时拒绝并保守保留 2048 微元占额。单价、两倍缓冲和原有 token 限额未放宽。 |
| 未知用量、落盘与重启 | Worker 实际测试记录 `usageUnknown=true`、`actualMicrounits=null`，重开独立 JSON 后仍 held 2048 微元；Agent 内存测试同样保留未知状态和占额。测试没有用实际费用 0 代替未知费用；`spent=0` 与独立的 held 占额同时存在。 |
| 跨核价版本上限 | [预算账本](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/api/src/modules/ai/budget-ledger.js:70) 累计任务预留按 account／job 汇总，日账本按 account／北京日期汇总，均未按 priceVersion 重开额度。旧版本五项未知预留各 2 元、重启后仍占满 10 元；新版本同任务重试拒绝，新的 Worker 调用也因日总额拒绝。该项独立回归通过。 |
| API／桌面同源 | [API 装配](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/api/src/app.factory.js:215) 与 [桌面装配](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/desktop-runtime/src/runtime-services.mjs:72) 直接传入同一 API 源档案；隔离 Worker 经 IPC 传递该档案。桌面构建入口可沿导入收集（仅静态读取，未构建／运行 App）。 |
| 显式执行与一次注册 | [轻量 runner](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-price-refresh/apps/api/test/run-price-tests.js:10) 显式执行 `testCase.run()`。新增 9 项经 `aiBudgetWorkerTests` 接入常规 runner，既有 HTTP case 仍在 `aiAssistantHttpTests`，两个数组各在常规 runner 注册一次；没有把 import 当测试通过。 |
| 时间与隔离边界 | 新价格测试固定复核时间／迁移日期，明确断言新版版本及截止，没有延长生产档案以使到期测试通过。既有 HTTP case 的过期断言改取正式 `profile.expiresAt`；其当前能力测试依赖运行时当天仍处于复核窗口，本次执行日期为 2026-10-02。HTTP context 固定临时 JSON、独立上传目录；凭据引用在任何请求前替换为合成值。 |
| 文档与历史 | 本批涉及的 10 个本地链接均存在；工程日志使用现有“多端”标签。`AI-01-07` 只新增后续核价段，移除该段后内容与 base 完全一致；保留 9/27 真实调用／构建历史并明确其不能证明新档案、共享预算实网或安装 App 更新。 |

## 独立执行及证据

环境：Node.js `v24.19.0`，PATH 使用获准 Node 24 runtime。执行命令：

```sh
KNOWRA_AI_ENABLED=1 KNOWRA_AI_EGRESS_ENABLED=1 node apps/api/test/run-price-tests.js
git diff --check 3811447f5f2243278fa7de823b3d359ff5e7e13c 7c69f18acc90aa0ce748c0d8844f14c9c6a1e390
```

默认沙箱中前 9 项通过，最后一项 `listen EPERM 127.0.0.1`。随后自动审批允许固定 runner 的合成临时回环验收，重跑得到完整 10/10 与退出码 0；没有自动审批拒绝或未解决的环境阻塞。`git diff --check` 通过。

- [独立 target 原始日志](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/核价-7c69-Max-target.log)。
- [默认沙箱原始日志](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/核价-7c69-Max-target-sandbox.log)。
- [独立身份／命令 metadata](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/核价-7c69-Max-metadata.json)。
- [独立哈希／链接／差异检查](/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/核价-7c69-Max-static.json)。

提供的 `/tmp/knowra-official-pricing-20261002-refetch.html` 与源树 `dist/price-evidence/official-pricing-20261002.html` 均为 24,116 字节，独立复算 SHA-256 同为 `5a7b1832592387340f2fc456399b34b89b05f3fa167c2e35909e2fa4afe021e3`；根价格来源 JSON 与 `dist/price-evidence/source.json` 字节及哈希一致。manifest 中 **15/15** 文件的长度／哈希一致。

读取了提供的红／绿日志：旧正式档案初期 1/8，7 项预期失败；刷新后旧 HTTP 截止断言报 `Missing expected exception`。`profile-before.json` 与实际 base 源档案字段完全一致，`assistant-http-before.js` 与实际 base 文件逐字节一致。本次未重新运行旧源码红测。已有 green/manifest 绑定实现 head `d6f39c06f4bd68970eba11565ecbeaaf5a8cb787`／tree `a72dbadd5a2d0f3bb25e61e8e94948d616430527`；d6f→7c69 仅三份导航／历史文档改变，本次另有固定 7c69 独立 green。

## 未验范围与后续身份

本次只执行合成轻量工程测试：临时 JSON／内存、离线 mock 和一条临时 `127.0.0.1` HTTP case。没有读取／设置真实凭据、发送真实笔记、供应商调用、账单核验、PostgreSQL、远端预算实网、打包／已安装 App 或服务器运行验收；没有全套 API／桌面／Web／E2E、build、browser、CI 或远端 Git 权威核验，也没有 clipboard／生产／resetcard 操作。

上述未验范围不由 10/10 或公开价格页推出。固定 head 审查无剩余阻塞；后续同步 main、合并队列或最终冻结产生的新 head 需由整合流程重新绑定验证，本报告不覆盖那些新身份。

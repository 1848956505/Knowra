import { useState } from 'react';
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { createEmptyWorkspaceSnapshot, type WorkspaceApi } from '@study-accelerator/web-core';
import fs from 'node:fs';
import { App } from '../knowra-command-search/apps/web-v4/src/app/App';
import { AppProviders } from '../knowra-command-search/apps/web-v4/src/app/AppProviders';
import { RouterProvider } from '../knowra-command-search/apps/web-v4/src/app/router';
import { createAppStore } from '../knowra-command-search/apps/web-v4/src/store/createAppStore';
import { createKnowledgeModule } from '../knowra-command-search/apps/api/src/modules/knowledge/index.js';

const startup = vi.hoisted(() => {
  let release!: () => void;
  const gate = new Promise<void>(yes => { release = yes; });
  return { gate, release, requested: false, realModuleLoaded: false };
});
// 仅延迟真实编辑器模块交付，模拟 cold/lazy load；组件及正文行为使用原模块。
vi.mock('../knowra-command-search/apps/web-v4/src/features/editor/MilkdownNoteEditor', async importOriginal => {
  startup.requested = true;
  const actual = await importOriginal();
  startup.realModuleLoaded = true;
  await startup.gate;
  return actual;
});

it('独立诊断：编辑标题与Dialog关闭先完成，立即正文断言失败，异步挂载后同断言成立', async () => {
  Object.defineProperty(HTMLElement.prototype, 'scrollTo', { configurable: true, value: vi.fn() });
  const knowledge = createKnowledgeModule({ enforceReferences: true });
  const space = knowledge.knowledgeSpaceService.createDefaultKnowledgeSpace({ userId: 'demo' });
  const api = createWorkspaceApiStub({ notes: [] });
  vi.mocked(api.listKnowledgeSpaces).mockResolvedValue([space]);
  api.loadWorkspaceResources = vi.fn(async () => ({ folderTree: [], tags: [], tagGroups: [],
    notes: knowledge.noteService.listNotes({ spaceId: space.id, summaryOnly: true }) }));
  api.getNote = vi.fn(async id => knowledge.noteService.getNote(id));
  api.searchCommandNotes = vi.fn(async input => knowledge.searchService.searchCommandNotes(input, 'demo'));
  const store = createAppStore({ api, cacheKey: 'synthetic-editor-mount-probe', mockSnapshot: createEmptyWorkspaceSnapshot() });
  const routes: string[] = [];
  function Harness() {
    const [pathname, setPathname] = useState('/');
    const navigate = (next: string) => { routes.push(next); setPathname(next); };
    return <RouterProvider location={{ pathname, navigate }}><AppProviders store={store}><App /></AppProviders></RouterProvider>;
  }
  render(<Harness />);
  await waitFor(() => expect(store.getState().dataMode).toBe('api'));
  expect(store.getState().serverData.notes).toHaveLength(0);
  const note = knowledge.noteService.createNote({ id: 'mount-unknown-note', spaceId: space.id,
    title: '独立冷启动未知正文资料', rawMarkdown: '# 合成正文\n\n' + '前文内容。'.repeat(100) + '冷启动正文命中' });
  fireEvent.keyDown(window, { key: 'k', ctrlKey: true });
  const dialog = await screen.findByRole('dialog', { name: '全局搜索' });
  fireEvent.change(within(dialog).getByRole('combobox'), { target: { value: '冷启动正文命中' } });
  await within(dialog).findByRole('option', { name: /独立冷启动未知正文资料/ });
  fireEvent.keyDown(within(dialog).getByRole('combobox'), { key: 'Enter' });
  try {
    expect(await screen.findByRole('heading', { name: note.title, exact: true })).toBeInTheDocument();
    await waitFor(() => expect(screen.queryByRole('dialog', { name: '全局搜索' })).not.toBeInTheDocument());
    await waitFor(() => expect(startup.realModuleLoaded).toBe(true));
    const before = { titlePresent: true, dialogPresent: !!screen.queryByRole('dialog', { name: '全局搜索' }),
      editorPresent: !!document.querySelector('.ProseMirror'), startupMessagePresent: !!screen.queryByText('正在启动编辑器…'),
      getNoteCalls: vi.mocked(api.getNote).mock.calls, selectedNoteId: store.getState().navigation.selectedNoteId,
      storedNoteIds: store.getState().serverData.notes.map(item => item.id), route: routes.at(-1) };
    expect(document.querySelector('.ProseMirror')).toBeNull();
    expect(screen.getByText('正在启动编辑器…')).toBeInTheDocument();
    // 原CI的立即正文断言在合法的lazy阶段必然失败。
    expect(() => expect(document.querySelector('.ProseMirror')).toHaveTextContent('冷启动正文命中')).toThrow();
    startup.release();
    // 保留正文必须实际出现的同等断言，等待其用户可见条件成立。
    await waitFor(() => expect(document.querySelector('.ProseMirror')).toHaveTextContent('冷启动正文命中'));
    const after = { editorPresent: !!document.querySelector('.ProseMirror'),
      bodyContainsExpected: document.querySelector('.ProseMirror')?.textContent?.includes('冷启动正文命中'),
      missingHeadingPresent: !!screen.queryByRole('heading', { name: '未找到这篇笔记', exact: true }),
      getNoteCalls: vi.mocked(api.getNote).mock.calls, route: routes.at(-1) };
    expect(api.getNote).toHaveBeenCalledExactlyOnceWith(note.id);
    expect(api.loadWorkspaceResources).toHaveBeenCalledTimes(1);
    fs.writeFileSync('/Users/rabbids/Documents/Codex/2026-10-01/task-3/审查证据/CmdK-140-Max-editor-mount-observation.json', JSON.stringify({
      head: '140c2ee5d887fbe28299068d3eb96e93b2c75f42', testKind: 'real module delayed synthetic App/Router diagnostic',
      assertionRaceConfirmed: true, before, after, completedAt: new Date().toISOString()
    }, null, 2) + '\n');
  } finally { startup.release(); }
});

function createWorkspaceApiStub(overrides: { notes?: Array<Record<string, unknown>> } = {}): WorkspaceApi {
  const defaultNote = {
    id: 'note-1',
    spaceId: 'space-1',
    title: 'Note',
    folderId: 'folder-1',
    tagIds: [],
    internalLinks: [],
    rawMarkdown: '',
    contentLoaded: false,
    favorite: false,
    deleted: false
  };
  const notes = overrides.notes !== undefined ? overrides.notes : [defaultNote];
  return {
    listKnowledgeItems: vi.fn().mockResolvedValue([]),
    listTrainingAssets: vi.fn().mockResolvedValue([]),
    listKnowledgeSpaces: vi.fn().mockResolvedValue([{ id: 'space-1', name: 'Main' }]),
    createDefaultKnowledgeSpace: vi.fn().mockResolvedValue({ id: 'space-1', name: 'Main' }),
    loadWorkspaceResources: vi.fn().mockResolvedValue({
      folderTree: [{ id: 'folder-1', name: 'Folder', parentId: null, children: [] }],
      notes,
      tags: []
    }),
    searchNoteIds: vi.fn().mockResolvedValue([]),
    createNote: vi.fn().mockResolvedValue({ id: 'created-note' }),
    importMarkdownNotes: vi.fn().mockResolvedValue([{ id: 'imported-note' }]),
    getNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    createFolder: vi.fn().mockResolvedValue({ id: 'created-folder' }),
    updateNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    deleteNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    restoreNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    permanentlyDeleteNote: vi.fn().mockResolvedValue({ id: 'note-1' }),
    setNoteFavorite: vi.fn().mockResolvedValue({ id: 'note-1' }),
    setNoteTags: vi.fn().mockResolvedValue({ id: 'note-1' }),
    createTag: vi.fn(), updateTag: vi.fn(), deleteTag: vi.fn(), mergeTags: vi.fn(), reorderTags: vi.fn(),
    createTagGroup: vi.fn(), updateTagGroup: vi.fn(), deleteTagGroup: vi.fn(),
    deleteNotes: vi.fn().mockResolvedValue([]),
    assignTagToNotes: vi.fn().mockResolvedValue([]),
    updateTagsForNotes: vi.fn().mockResolvedValue([]),
    queryNotes: vi.fn().mockResolvedValue({ items: notes, hasNext: false }),
    getLinkedNotes: vi.fn().mockResolvedValue([]),
    listAnnotations: vi.fn().mockResolvedValue([]),
    createAnnotation: vi.fn(),
    deleteAnnotation: vi.fn(),
    restoreAnnotation: vi.fn(),
    updateAnnotationAnchor: vi.fn(),
    listNoteVersions: vi.fn().mockResolvedValue([]),
    getNoteVersion: vi.fn().mockResolvedValue({ id: 'version-1' }),
    listNoteAttachments: vi.fn().mockResolvedValue([]),
    uploadNoteAttachment: vi.fn().mockResolvedValue({ id: 'attachment-1' }),
    renameNoteAttachment: vi.fn().mockResolvedValue({ id: 'attachment-1' }),
    inspectAttachmentDeletion: vi.fn().mockResolvedValue({ asset: { type: 'attachment', id: 'attachment-1' }, decision: 'can-purge-no-history', references: [], reasonCodes: [], coverage: { persistedCurrentAndHistory: true } }),
    verifyNoteAttachment: vi.fn(),
    restoreNoteAttachment: vi.fn(),
    listAttachmentCleanup: vi.fn().mockResolvedValue({ items: [], pending: 0 }),
    retryAttachmentCleanup: vi.fn().mockResolvedValue({ completed: 0, pending: 0 }),
    deleteNoteAttachment: vi.fn().mockResolvedValue({ id: 'attachment-1' }),
    updateFolder: vi.fn().mockResolvedValue({ id: 'folder-1' }),
    deleteFolder: vi.fn().mockResolvedValue([]),
    emptyRecycleBin: vi.fn().mockResolvedValue({ deletedCount: 0 })
  };
}

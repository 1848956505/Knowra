# CmdK 正文搜索 140c 固定提交独立 Max 复审

结论：旧 5ad 的“有效服务端未知 ID 命中打不开”**P2 业务缺陷已由未改断言的独立回归关闭**。140c 的完整功能差异未发现其他可复现的应用实现 P0/P1/P2/P3。当前仍有 **1 项 P2 测试同步缺陷**：新 App 结果测试在真实编辑器异步挂载前立即断言正文，已造成本提交真实 CI 失败；独立真实模块延迟诊断确证原因。因此当前不能记为全部门禁通过，需最小修复后冻结新 HEAD 并重跑 CI、生产单条与最终合并提交审查。

只读源树为 `/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search`；AGENTS、开发规范、相关结构导航与领域入口沿用并复核。全部 feature diff 及 P2 增量均已审查，以当前实现为准。

| 对象 | 固定值 |
| --- | --- |
| 完整 HEAD | `140c2ee5d887fbe28299068d3eb96e93b2c75f42` |
| tree | `e3ba9df903d0ac80c4c7127599e03e043715bea5` |
| branch | `feat/command-body-search` |
| feature base | `3811447f5f2243278fa7de823b3d359ff5e7e13c` |
| P2 增量 base | `5ad5626b9db35c5b2bebea8c49a416d74d28413d` |
| 工作区开始/结束 | porcelain 为空，HEAD/tree 一致；34 个差异文件 SHA-256 全部一致 |
| 差异范围 | feature 34 文件，1565 行增加、46 行删除；P2 增量 13 文件 |
| 独立原测试 | test 与 config SHA-256 开始/结束一致；保留原 5ad red 与报告 |

开始 UTC `2026-10-02T15:40:25.956188+00:00`，结束一致性核验 UTC `2026-10-02T15:57:22.444795+00:00`。身份与文件证据见 [start](CmdK-140-Max-start.json)、[end](CmdK-140-Max-end.json)、[完整 feature patch](CmdK-140-Max-feature-diff.patch)、[P2 patch](CmdK-140-Max-p2-diff.patch)。没有用旧生产资源或旧提交的通过结果替代新 HEAD 验收。

## P2：新正文结果测试等待条件不足，使 CI 在合法挂载阶段失败

位置：[App.test.tsx:718](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/app/App.test.tsx:718)。测试等待该笔记标题出现以及 Dialog 消失后，直接执行 `expect(document.querySelector('.ProseMirror')).toHaveTextContent(...)`。

标题与 Dialog 状态由详情读取、store 写入和导航完成决定；它们并不表示编辑器已经完成挂载。[NoteEditorView.tsx:74](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/features/editor/NoteEditorView.tsx:74) 用 React lazy 导入实际编辑器，[NoteEditorView.tsx:887](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/features/editor/NoteEditorView.tsx:887) 允许此时显示“正在启动编辑器…”，编辑器自身还异步创建实例。冷加载或测试调度的差异可以使 `.ProseMirror` 在该断言时为 null，随后正常显示正文。

已发生的真实影响：[CI run 37028454076](https://github.com/1848956505/Knowra/actions/runs/37028454076)，对应完整 head 140c。Node 24 job 失败，V4 为 **568 passed / 1 failed，569 总计**，唯一失败正是此用例，错误为 `received value must be a Node; Received has value: null`，定位 718 行。容器 job 成功，Node 的构建/架构/身份检查成功，但测试步骤失败后生产 Chromium 步骤被跳过。这不是 R07、供应商或额度错误。父线程提供的原始 CI 内容已保存为 [failed log](CmdK-140-Max-ci-failed.log) 和 [run/PG/失败摘要 JSON](CmdK-140-Max-ci-result.json)，没有借本地 99/99 否认该失败。

独立确定性诊断使用真实 App、RouterProvider、store、当前正式内存知识模块后端、真实 Milkdown 模块，仅把模块交付阻塞在一个可释放 Promise 上。先完成页面摘要加载，再新增当前 owner/space 的未知 ID；搜索词位于 500 字前文之后。选择后的实际观测如下：

| 状态 | 模块交付之前 | 释放真实模块并等正文之后 |
| --- | --- | --- |
| 该笔记标题 | 出现 | 出现 |
| 全局搜索 Dialog | 已关闭 | 已关闭 |
| route | `/materials/notes/mount-unknown-note` | 同路径 |
| selectedNoteId / store | 正确未知 ID，已插入详情 | 保持正确 |
| getNote | 恰好一次，请求该 ID | 仍恰好一次 |
| `.ProseMirror` | null；存在“正在启动编辑器…” | 存在且含完整预期正文 |
| “未找到这篇笔记” | 未单列观测（正确标题与加载提示已出现） | 没有出现 |

诊断在阻塞阶段证明原立即正文断言会抛错；随后对**相同正文内容要求**使用 `waitFor`，实际编辑器挂载后通过，**1/1**。由此确认是测试同步缺口，而非详情 loader 失败。证据为 [诊断 test](CmdK-140-Max-editor-mount.test.tsx)、[独立 config](CmdK-140-Max-editor-mount.vitest.config.mjs)、[原始 log](CmdK-140-Max-editor-mount.log)、[执行 JSON](CmdK-140-Max-editor-mount.json)、[DOM/store/GET 观测 JSON](CmdK-140-Max-editor-mount-observation.json)。首个外部诊断夹具因换行字面量生成错误未执行任何测试，单独保留 `editor-mount-fixture-parse-attempt.*`，不计作业务失败。

建议只把该正文断言纳入等待实际正文出现的 `waitFor`，保留正文内容、真实页面、详情 GET、仅一次摘要、store/navigation/URL 及缺失页面排除等原断言；不以 sleep、跳过或只验标题代替用户结果。随后在新固定 HEAD 重跑定向检查与 CI。

## 原业务 P2 关闭及实现核查

[原 5ad 审查](CmdK-5ad固定独立Max审查.md) 和 [有效业务 red](CmdK-5ad-Max-remote-opening.log) 保留原样。本次在原 test/config SHA 不变、web-core 映射当前源代码、未构建的条件下重新执行，**1/1 通过**：[log](CmdK-140-Max-original-probe.log)、[JSON](CmdK-140-Max-original-probe.json)。原夹具仍先加载空摘要，再由正式后端新增笔记，正文搜索词在 500 字前文之后；必须找到正确 option、导航到正确 URL、出现实际编辑标题并调用该 ID 的 getNote。未将未知 ID 预装进摘要或删减原业务断言。

额外的真实编辑器延迟诊断还独立验证了正文最终出现、没有缺失笔记页面、getNote 恰好一次且摘要只加载一次。因此关闭结论不只来自 URL 或标题。

- [commandNoteOpening.ts:15](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/store/commandNoteOpening.ts:15) 仅在 ready/API/current space 范围载入详情。已有笔记沿用旧编辑路由 loadNoteContent；未知 ID 使用已有完整 getNote，校验 ID、spaceId、非 deleted、字符串标题/Markdown，显式归一化插入完整内容与缓存，不把搜索片段当正文。getNote 旧协议没有新增 owner 参数；权限范围来自当前已获服务端 owner 校验的空间，并再次核对详情 spaceId。
- loader 在等待前保留 serverData 身份、mode、load state、generation；返回前结合 selection 的 `isCurrent` 检查，迟到成功/失败不会写入新快照或影响新选择。`applyWorkspaceSnapshot` 的加载/恢复入口会产生新 serverData/navigation，满足这里及 App 的失效条件。该路径没有新增数据库 schema 或迁移。
- [useCommandSelection.ts:17](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/shell/useCommandSelection.ts:17) 用 scope 与请求序号控制异步完成。关闭、改输入、清空、IME start、unmount、后续选择取消旧请求；错误可见且重试可行；不会因 App inline callback 重建就取消当前合法选择。loading 期间阻断重复 Enter。
- [App.tsx:364](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/web-v4/src/app/App.tsx:364) 额外绑定 origin path/navigation、导航 Guard，并在详情回执后验证返回的完整 snapshot、当前空间/模式/代际和笔记对象身份。**loader 快照回执间隙测试已实际运行通过**：详情已返回但选择前置换 serverData，不得导航或打开已失效 note。空间往返、同空间新快照、关闭/查询变化/另行导航、新 B 先完成旧 A 迟到成功或失败均在实际 99 个目标内通过。
- 现有笔记内容/草稿/save state/navigation 不被未知详情插入顺带覆盖；原 update helper 的 insertMissing 默认 false，只由专门 loader 显式开启。缓存与已有 store 写入基线通过。
- feature API、共享 DTO 与同步/异步 handler 自 5ad 没有进一步变动，本次重新审查完整差异并重跑 API/core。JSON、SQLite、async factory 的 server owner 装配继续有效；请求不接受客户端 owner 覆盖，当前 space 强制非 deleted，最多 30 个四字段命中、snippet ≤220 UTF-16，没有 raw/full plainText。参数上限、安全整数、中文/emoji/大小写扩长、legacy ids/full notes 和 NotesIndex recycle 契约有实际目标覆盖。
- 检索 scope render 即时隔离、防抖 180ms、错序/A→B→A、空间切换、IME/229、error/loading Enter、远端正文不二次 title filter、同 ID 去重、已有标签/主页与导航兼容目标通过。

## 本次实际运行与证据

所有本地执行都为轻量指定目标和合成数据，Node 为指定的 Node 24；没有全套、build、browser、GUI、Electron、安装、App 操作或本地 PG。表中通过只代表各自列出的范围。

| 检查 | 本次结果 | 原始记录 |
| --- | --- | --- |
| 显式 API `node apps/api/test/run-command-search-tests.js` | 33/33；本地真实 PG SKIP | [log](CmdK-140-Max-api-target.log)、[JSON](CmdK-140-Max-api-target.json) |
| core command-note-search / api-client | 30/30 | [log](CmdK-140-Max-core-target.log)、[JSON](CmdK-140-Max-core-target.json) |
| V4 App / SearchCommand / commandNoteOpening / commandNoteSearch / createAppStore | 99/99：41+15+15+2+26 | [log](CmdK-140-Max-ui-target.log)、[JSON](CmdK-140-Max-ui-target.json) |
| 未改的原独立未知 ID 业务断言 | 1/1；旧 P2 关闭 | [log](CmdK-140-Max-original-probe.log)、[JSON](CmdK-140-Max-original-probe.json) |
| 新独立真实编辑器挂载诊断 | 1/1；确证立即断言 race、同正文等待成功 | [log](CmdK-140-Max-editor-mount.log)、[JSON](CmdK-140-Max-editor-mount.json) |
| core/V4 tsc、boundaries、diff check、12 JS/MJS nodecheck | 16 项全部通过 | [log](CmdK-140-Max-static.log)、[JSON](CmdK-140-Max-static.json) |
| 140c 实际远端 CI | Node failure，V4 568/569；上述 P2 | [CI log](CmdK-140-Max-ci-failed.log)、[JSON](CmdK-140-Max-ci-result.json) |
| 140c CI 真实 PostgreSQL 命令正文搜索 HTTP | **PASS**，UTC `2026-10-02T15:40:08.5627782Z`；异步路由、有界投影、当前空间/owner 隔离 | 同上，保留原始完整 PASS 行 |

API 为获准的临时合成根与随机 127.0.0.1 端口定向 runner；之前 5ad 的 sandbox EPERM 不是业务失败，也不是额度故障。本次不启动或连接本地数据库。本机两个 PG gate 未启用，但 **140c 的真实 CI 已执行 PG 用例并通过**；不能将当前候选真实 PG 写成未测。将来新提交仍需它自己的 CI。

## 生产夹具、文档及 pending 边界

新生产单条的源代码已完整审查：[command-search.test.mjs:62](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/desktop-runtime/test/e2e/command-search.test.mjs:62) 先 reload 并等收到预载对照摘要与工作台；[第 78 行](/Users/rabbids/Documents/Codex/2026-10-01/task-3/knowra-command-search/apps/desktop-runtime/test/e2e/command-search.test.mjs:78) 后新增目标，断言初次摘要不含它、当前页面对应按钮为 0。额外 HTTP 摘要证明 240 字摘要不含正文词，也没有完整正文；真实 CmdK response 必须是四字段 DTO。Enter 前设置详情 GET 观察与等待，要求 200、正确 ID/空间/非 deleted/完整 rawMarkdown，只读取一次；随后等待真实编辑正文，校验路径与缺失状态，回执写 `targetPreloaded:false/detailStatus:200/detailRequestCount:1`。这确实改变了旧夹具只覆盖摘要内 ID 的前提。

desktop 与 390px 的 Range 断言检查命中词全部 UTF-16 范围的每个矩形落于 snippet 可见边界，严格于 DOM contains；新 CSS 与对应生产断言不能借旧包绿色继承。文档准确注明 d35 原单条绿色、新断言在旧 CSS 上真实 red（父线程的 15:06:33Z 证据）及 P2 新生产绿色仍待运行；本次未执行浏览器，不对新生产绿色做推断。文档的 99/99 定向结果由本次独立重现，不能扩展为完整 CI 绿色。

仍待完成：

1. 修复本次 P2 测试同步缺口，冻结新完整 HEAD/tree，保留旧正文/GET/summary/store/URL 断言，定向复验及真实 CI 全部门禁。
2. 父线程在获准重型窗口对新 clean build 实际执行新版 SQLite/HTTP/Chromium 单条，记录 buildInfo、desktop/390px 可见性和未知 ID 详情 GET 的 green；140c CI 的 Chromium 步骤因测试失败被跳过，本次不得记为生产通过。
3. PR 队列按父线程安排完成、同步 main 后，以最终完整 HEAD/tree 再审查与核对真实 CI；本报告仅覆盖固定 140c。

本次没有修改源树、commit/rebase/push/merge/部署或 CI 编排，没有接触真实笔记、凭据、系统剪贴板、reset cards，也没有读取/运行父线程独占的 R07 fixture/test。没有额度不足、重置或降档。审查结束可释放 140c freeze 供父线程进行已明确的最小测试修复；新提交的通过结论须重新取得。
